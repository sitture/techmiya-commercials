from django.contrib import admin
from myproject.techmiya.models import *

admin.site.register(Vehicle)
admin.site.register(Picture)
admin.site.register(ContactDetail)

